<?php

class Article
{
    public $id; // Agregar ID público para facilitar el acceso
    private $dni;
    private $titol;
    private $cos;

    // Constructor 
    public function __construct($dni, $titol, $cos)
    {
        $this->dni = $dni;
        $this->titol = $titol;
        $this->cos = $cos;
    }

    // Getters
    public function getId()
    {
        return $this->id;
    }

    public function getDni()
    {
        return $this->dni;
    }

    public function getTitol()
    {
        return $this->titol;
    }

    public function getCos()
    {
        return $this->cos;
    }

    // Setters
    public function setId($id)
    {
        $this->id = $id;
    }

    public function setDni($dni)
    {
        $this->dni = $dni;
    }

    public function setTitol($titol)
    {
        $this->titol = $titol;
    }

    public function setCos($cos)
    {
        $this->cos = $cos;
    }
}
?>