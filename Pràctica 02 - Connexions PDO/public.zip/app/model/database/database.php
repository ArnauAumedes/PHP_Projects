<?php
class Database {
    private $host = '127.0.0.1'; 
    private $dbname = 'pt02_arnau_aumedes'; 
    private $username = 'root';
    private $password = '';
    private $charset = 'utf8mb4';
    private $pdo;

    public function __construct() {
        $this->connect();
    }

    private function connect() {
        // DSN (Data Source Name)
        $dsn = "mysql:host={$this->host};dbname={$this->dbname};charset={$this->charset}";

        // Opcions de PDO
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Mode d'errors
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // Mode de recuperació per defecte
            PDO::ATTR_EMULATE_PREPARES   => false,                  // Desactivar emulació de prepares
        ];

        try {
            // Crear la connexió PDO
            $this->pdo = new PDO($dsn, $this->username, $this->password, $options);
        } catch (PDOException $e) {
            // Gestió d'errors
            die('Error de connexió: ' . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->pdo;
    }
}
?>