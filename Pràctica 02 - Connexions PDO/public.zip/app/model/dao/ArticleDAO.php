<?php
require_once __DIR__ . '/../entities/Article.php';

class ArticleDAO extends Article 
{
    private $db; // PDO

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    // CREAR: Utilitzar $_POST per obtenir dades del formulari, després crear objecte Article
    public function create()
    {
        // Obtenir dades del formulari ($_POST)
        $titol = $_POST['titol'] ?? '';
        $cos = $_POST['cos'] ?? '';
        $dni = $_POST['dni'] ?? null;

        // Crear objecte Article
        $article = new Article($dni, $titol, $cos);
        
        // Utilitzar getters per obtenir dades de l'objecte
        $sql = "INSERT INTO articles (titol, cos, dni) VALUES (:titol, :cos, :dni)";
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':titol', $article->getTitol(), PDO::PARAM_STR);
        $stmt->bindValue(':cos', $article->getCos(), PDO::PARAM_STR);
        $stmt->bindValue(':dni', $article->getDni(), PDO::PARAM_STR);
        $stmt->execute();
        
        return $this->db->lastInsertId();
    }

    // LLEGIR: Utilitzar $_GET per obtenir paràmetres de cerca
    public function findByDni()
    {
        // Obtenir DNI del paràmetre URL ($_GET)
        $dni = $_GET['dni'] ?? '';
        
        $stmt = $this->db->prepare("SELECT * FROM articles WHERE dni = :dni");
        $stmt->execute([':dni' => $dni]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row) {
            // Crear objecte Article i utilitzar setters
            $article = new Article($row['dni'], $row['titol'], $row['cos']);
            $article->setId($row['id']);
            return $article;
        }
        return null;
    }

    // LLEGIR per ID: Utilitzar $_GET per obtenir paràmetres de cerca
    public function findById()
    {
        // Obtenir ID del paràmetre URL ($_GET)
        $id = $_GET['id'] ?? '';
        
        $stmt = $this->db->prepare("SELECT * FROM articles WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row) {
            // Crear objecte Article
            $article = new Article($row['dni'], $row['titol'], $row['cos']);
            $article->setId($row['id']);
            return $article;
        }
        return null;
    }

    // ACTUALITZAR: Utilitzar $_POST per dades del formulari i $_GET per ID
    public function update()
    {
        // Obtenir ID de la URL ($_GET) i dades del formulari ($_POST)
        $id = $_GET['id'] ?? '';
        $dni = $_POST['dni'] ?? '';
        $titol = $_POST['titol'] ?? '';
        $cos = $_POST['cos'] ?? '';

        // Crear objecte Article
        $article = new Article($dni, $titol, $cos);
        
        // Utilitzar getters per accedir a les dades de l'objecte
        $sql = "UPDATE articles SET titol = :titol, cos = :cos, dni = :dni WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':titol' => $article->getTitol(),
            ':cos' => $article->getCos(),
            ':dni' => $article->getDni(),
            ':id' => $id
        ]);
        
        return $stmt->rowCount();
    }

    // ELIMINAR: Utilitzar $_GET per obtenir ID
    public function delete()
    {
        // Obtenir ID del paràmetre URL ($_GET)
        $id = $_GET['id'] ?? '';
        
        $stmt = $this->db->prepare("DELETE FROM articles WHERE id = :id");
        $stmt->execute([':id' => $id]);
        return $stmt->rowCount();
    }

    // OBTENIR TOTS ELS ARTICLES: Per mostrar en la vista principal
    public function findAll()
    {
        $stmt = $this->db->prepare("SELECT * FROM articles ORDER BY id ASC");
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $articles = [];
        foreach ($rows as $row) {
            $article = new Article($row['dni'], $row['titol'], $row['cos']);
            // Agregar el ID manualmente ya que no está en el constructor
            $article->id = $row['id'];
            $articles[] = $article;
        }
        
        return $articles;
    }
}   
?>