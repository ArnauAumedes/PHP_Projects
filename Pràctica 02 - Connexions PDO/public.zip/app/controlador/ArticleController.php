<?php
// filepath: c:\xampp\htdocs\practicas\Pràctica 02 - Connexions PDO\app\controller\ArticleController.php
require_once __DIR__ . '/../model/entities/Article.php';
require_once __DIR__ . '/../model/dao/ArticleDAO.php';  // Esta línea faltaba
require_once __DIR__ . '/../model/database/database.php';

class ArticleController
{
    private $articleDAO;
    private $db;

    public function __construct()
    {
        // Utilitzar la classe Database centralitzada
        $database = new Database();
        $this->db = $database->getConnection();
        $this->articleDAO = new ArticleDAO($this->db);
    }

    // Manejar totes les peticions
    public function handleRequest()
    {
        $action = $_GET['action'] ?? 'menu';

        switch ($action) {
            case 'create':
                $this->createArticle();
                break;
            case 'update':
                $this->updateArticle();
                break;
            case 'delete':
                $this->deleteArticle();
                break;
            case 'menu':
            default:
                $this->showMenu();
                break;
        }
    }

    // CREAR article
    private function createArticle()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                // El DAO s'encarrega d'obtenir les dades de $_POST
                $result = $this->articleDAO->create();

                if ($result) {
                    // Redirigir al menú con mensaje de éxito
                    header("Location: /practicas/Pràctica 02 - Connexions PDO/public/index.php?created=success&id=" . $result);
                    exit();
                } else {
                    // Redirigir al menú con mensaje de error
                    header("Location: /practicas/Pràctica 02 - Connexions PDO/public/index.php?created=error");
                    exit();
                }
            } catch (Exception $e) {
                // Redirigir al menú con mensaje de error
                header("Location: /practicas/Pràctica 02 - Connexions PDO/public/index.php?created=error&msg=" . urlencode($e->getMessage()));
                exit();
            }
        } else {
            // Mostrar formulari de creació
            include __DIR__ . '/../vista/create.php';
        }
    }

    // ACTUALITZAR article
    private function updateArticle()
    {
        $article = null;
        $message = "";

        // Si és POST, actualitzar
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                // El DAO s'encarrega d'obtenir les dades de $_POST i $_GET
                $rowsAffected = $this->articleDAO->update();

                if ($rowsAffected > 0) {
                    // Redirigir al menú con mensaje de éxito
                    header("Location: /practicas/Pràctica 02 - Connexions PDO/public/index.php?updated=success");
                    exit();
                } else {    
                    $message = "No s'ha pogut actualitzar l'article";
                }
            } catch (Exception $e) {
                $message = "Error: " . $e->getMessage();
            }
        }

        // Si hi ha ID, buscar l'article per mostrar-lo
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            try {
                $article = $this->articleDAO->findById();
                if (!$article) {
                    $message = "No s'ha trobat cap article amb aquest ID";
                }
            } catch (Exception $e) {
                $message = "Error cercant l'article: " . $e->getMessage();
            }
        }

        // Carregar vista
        include __DIR__ . '/../vista/update.php';
    }

    // ELIMINAR article
    private function deleteArticle()
    {
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            try {
                $id = $_GET['id'];
                // El DAO s'encarrega d'obtenir l'ID de $_GET
                $rowsAffected = $this->articleDAO->delete();

                if ($rowsAffected > 0) {
                    // Redirigir al menú con mensaje de éxito
                    header("Location: /practicas/Pràctica 02 - Connexions PDO/public/index.php?deleted=success&id=" . $id);
                    exit();
                } else {
                    // Redirigir al menú con mensaje de error
                    header("Location: /practicas/Pràctica 02 - Connexions PDO/public/index.php?deleted=error");
                    exit();
                }
            } catch (Exception $e) {
                // Redirigir al menú con mensaje de error
                header("Location: /practicas/Pràctica 02 - Connexions PDO/public/index.php?deleted=error&msg=" . urlencode($e->getMessage()));
                exit();
            }
        } else {
            // Redirigir al menú si no hay ID
            header("Location: /practicas/Pràctica 02 - Connexions PDO/public/index.php?deleted=noid");
            exit();
        }
    }

    // Mostrar menú principal
    private function showMenu()
    {
        // Obtener todos los artículos de la base de datos
        try {
            $articles = $this->articleDAO->findAll();
        } catch (Exception $e) {
            $articles = [];
            $error_message = "Error al cargar los artículos: " . $e->getMessage();
        }
        
        include __DIR__ . '/../vista/menu.php';  // Cambiar a la vista del menú
    }
}
?>